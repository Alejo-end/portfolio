# maxforlive.com listing, version 2.0

Paste these fields into the existing listing at
https://maxforlive.com/library/device/14101/sounds-of-the-weather-turning

## Fields

Name: Sounds of the weather turning
Version: 2.0
Device Type: Audio Effect
Live Version Used: 12.4.6
Max Version Used: 9.1.5
Device File: the frozen `sounds_of_the_weather_turning_v2.amxd`
License: AttributionShareAlike (no change)

## Description

A Max for Live audio effect that turns the live weather of a city into sound and an animated picture.

Pick one of 29 cities. The device reads the current weather from Open-Meteo and moves seven dials: Air Quality, Temperature, Humidity, Wind, Pollution, Precipitation and Pressure. The dials drive a shimmer reverb, an echo, a delay and a Roar distortion, made with the ABL objects of Max 9. The picture shows the skyline of the city, the sky at the local time, and the rain, snow, fog, haze and wind.

No API key is needed. If you change the city, the device fetches the weather at once. It also fetches it every 10 minutes.

Controls:
- Mode: in Weather mode the weather moves the dials. In Manual mode you play them by hand, with MIDI or with automation.
- Delay: the echo and delay mix, the delay time and the speed of the reverb movement.
- Freeze: an endless reverb tail, ping-pong delay, and snow in the picture.
- Refresh: fetches the weather now.

Point at a control and read the Info View in Live to see what it changes.

Requirements: Live 12 with Max for Live and Max 9 or later, and an internet connection. Tested on macOS only.

Weather data: Open-Meteo.com, CC BY 4.0. The free Open-Meteo service is for non-commercial use.

Version 2 has new parameter names. Live sets made with version 1 need version 1.

Demo video: (add the new link)

This patch started in my Computational Art class at Aalto University, Finland.

## Version Changes

2.0:
- The weather comes from Open-Meteo. You need no API key.
- Real precipitation, cloud cover, weather codes, and day and night for each city.
- 29 cities, each with its own skyline. The picture is inside the device, so it works on every computer.
- A new Refresh button. A failed fetch keeps the last values.
- Pressure sets the reverb length, and the Roar filter follows the pollution.
- The shimmer pitch moves in whole semitones. If the delay time changes, the delay crossfades.

1.1: keep the text that the listing has now.

## Comment to post

Version 2.0 needs no API key. It gets the weather from Open-Meteo. The WAQI key in my first comment is only for version 1.1.
