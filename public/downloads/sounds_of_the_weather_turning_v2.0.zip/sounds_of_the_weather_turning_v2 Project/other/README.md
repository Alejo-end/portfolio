# Sounds of the Weather Turning, version 2

Sounds of the Weather Turning is a Max for Live audio effect. It reads the live weather of a city and turns it into an effect chain and an animated picture.

The device gets weather from Open-Meteo. Open-Meteo is a free weather service that needs no API key. The weather moves eight dials. The dials drive four Ableton effect modules and the picture.

## Files

| File | What it does |
| --- | --- |
| `sounds_of_the_weather_turning_v2.amxd` | The device. Freeze it before you share it (see Freeze and publish). |
| `code/weather.js` | Fetches the weather for the selected city and sends it to the dials and the picture. It runs in a `v8` object. |
| `other/weather-pixel.html` | The picture. It is one file with p5.js 1.11.10 inside, so it works offline and on other computers. p5.js is under the GNU LGPL 2.1 license, and the notice above its script block must stay. |
| `other/check-weather.mjs` | A test of `code/weather.js` against the live weather service. It needs Node.js, not Max. |
| `other/README.md` | This file. |
| `other/maxforlive-listing.md` | The text for the maxforlive.com listing of version 2.0. |

## How the device works

1. You select a city in the City menu.
2. `[p weather_fetch]` asks Open-Meteo for the current forecast and the air quality of that city.
3. The answer moves the dials: Air Quality, Temperature, Humidity, Wind, Pollution, Precipitation and Pressure.
4. The dials set the effects, and they send their values to the picture.
5. The device fetches again every 10 minutes. To change the interval, add a number of minutes to the box in `[p weather_fetch]`, for example `[v8 weather.js 5]`.

The dials are the one source of truth. Live automation, MIDI mapping and the weather all move the same dials. The picture always shows what the dials say.

The seven weather dials are in a grid next to the picture. Delay and Freeze have their own column on the right, because the weather does not move them. They are performance controls. The parameter bank for Push uses the order of the grid, with Delay last.

The Mode switch has two settings:

- In Weather mode, each fetch moves the seven weather dials. The dials are grey to show that the weather controls them. The weather code and the cloud cover from Open-Meteo add detail to the picture, for example fog, drizzle and thunder.
- In Manual mode, the fetch does not move the dials. You play the dials by hand or with MIDI. The picture follows the dials only. The sky still shows day or night for the selected city.

The Refresh button fetches at once. The text next to the City menu shows the state of the fetch:

- `fetched 14:32`: the time of the last good forecast for the selected city, on the clock of this computer. If a later fetch fails, the old time stays, so you can see the age of the data.
- `loading`: the first fetch for a new city is running.
- `no data`: the first fetch for a new city failed.

The Freeze button sets the shimmer reverb to an endless tail and turns on ping-pong in the delay. It also turns rain into snow in the picture. The weather does not press this button.

Each control has Info View text in Live. Point at a dial and read the Info View to see what it changes.

## Weather data

| Dial | Source | Range |
| --- | --- | --- |
| Air Quality | US AQI from the Open-Meteo air quality service | 0 to 300 |
| Temperature | Air temperature at 2 m | -20 to 45 °C |
| Humidity | Relative humidity at 2 m | 0 to 100 % |
| Wind | Wind speed at 10 m | 0 to 35 km/h |
| Pollution | PM2.5 | 0 to 200 µg/m³ |
| Precipitation | Rain or snow rate. The device uses the measured amount or a typical rate for the weather code, whichever is higher. | 0 to 15 mm per hour |
| Pressure | Pressure at sea level | 980 to 1040 hPa |

### Open-Meteo terms

- The free service is for non-commercial use only. If you sell the device, you need a paid Open-Meteo plan.
- The limits are 600 requests per minute, 5,000 per hour and 10,000 per day for each IP address. One device makes two requests every 10 minutes, plus two for each city change and each click on Refresh. That is about 290 requests per day.
- The data is under the CC BY 4.0 license. The credit "Data: Open-Meteo.com, CC BY 4.0" must stay next to the picture, under the dials. The device changes the data: it turns precipitation into a rate in mm per hour, and it uses a typical rate for each weather code.

### Checked on 21 October 2026

A test ran `code/weather.js` outside Max against the live service for all 29 cities. Every city returned a forecast and an air quality reading. All values were inside the ranges of the dials, and the day phase agreed with the day or night flag of Open-Meteo in every city. Late replies for a city that is no longer selected are ignored, and a failed request keeps the last values.

To run the same test again, open a terminal in the project folder and enter this command:

```
node other/check-weather.mjs
```

A second test ran in Max 9.0 with the real `v8`, `maxurl` and `jweb` objects:

- `maxurl` returns the reply with the JSON already parsed, and the HTTP status is 200.
- The `v8` timer fetches again on its own.
- Manual mode stops the dial output, and weather mode sends the dials again.
- When the city changes twice in a row, the device uses only the replies for the second city.
- The page loads in `jweb`, sends `ready`, receives the scene and reports its condition.

## Cities

The City menu and `code/weather.js` list the same 29 cities in the same order. The page draws these landmarks:

| City | Landmarks |
| --- | --- |
| Amsterdam | Canal houses with gables, Westerkerk, a windmill that turns with the wind |
| Barcelona | Sagrada Família, Torre Glòries, Montjuïc, the sea |
| Berlin | Fernsehturm, Brandenburg Gate, Reichstag dome |
| Bogotá | The eastern hills with Monserrate, Torre Colpatria, BD Bacatá |
| Buenos Aires | Obelisco, Palacio del Congreso, Puente de la Mujer, Puerto Madero |
| Cairo | The pyramids of Giza, Cairo Tower, a mosque with minarets, palms, the Nile |
| Copenhagen | Christiansborg, Church of Our Saviour, Nyhavn houses, offshore wind turbines |
| Delhi | India Gate, Jama Masjid, Lotus Temple, Qutub Minar |
| Dubai | Burj Khalifa, Burj Al Arab, Dubai Marina towers |
| Helsinki | Uspenski Cathedral, Helsinki Cathedral, the railway station tower, SkyWheel |
| Istanbul | Galata Tower, the Blue Mosque, Hagia Sophia, the Bosphorus |
| London | Elizabeth Tower and Parliament, London Eye, St Paul's, the Shard, Tower Bridge, the Gherkin |
| Mexico City | Popocatépetl and Iztaccíhuatl, Torre Latinoamericana, Torre Reforma, Ángel de la Independencia |
| Mumbai | Bandra-Worli Sea Link, Gateway of India, Taj Mahal Palace, towers |
| New York | Statue of Liberty, Empire State Building, Chrysler Building, One World Trade Center |
| Panama City | Bridge of the Americas, Ancon Hill, the Casco Viejo cathedral, F&F Tower, the sail tower of Punta Pacífica, a container ship |
| Paris | Eiffel Tower, Arc de Triomphe, Notre-Dame, Sacré-Cœur, Tour Montparnasse |
| Phoenix | Camelback Mountain, saguaro cacti, palms, downtown |
| Reykjavík | Hallgrímskirkja, Harpa, Esja with snow in the cold |
| Rio de Janeiro | Christ the Redeemer on Corcovado, Sugarloaf with its cable car, Copacabana |
| Rome | Colosseum, St Peter's Basilica, umbrella pines |
| San Francisco | Golden Gate Bridge, Transamerica Pyramid, Salesforce Tower |
| Seoul | N Seoul Tower on Namsan, Lotte World Tower, Bukhansan |
| Shanghai | Oriental Pearl Tower, Jin Mao Tower, Shanghai Tower, the "bottle opener" |
| Singapore | Marina Bay Sands, ArtScience Museum, Singapore Flyer, Supertrees |
| Sydney | Opera House, Harbour Bridge, Sydney Tower |
| Tokyo | Tokyo Tower, Tokyo Skytree, Mount Fuji |
| Toronto | CN Tower, Rogers Centre, Lake Ontario |
| Washington | Washington Monument, Capitol, Lincoln Memorial |

### Add a city

1. In `code/weather.js`, add a row to `CITIES` with the name, the latitude and the longitude.
2. In the device, open the inspector of the City menu. Add the same name to Range/Enum at the same position.
3. In `other/weather-pixel.html`, add an entry with the same name to `SKYLINES`. If you skip this step, the city gets a plain skyline.
4. Make sure that the three lists use the same spelling, accents included.

## The picture

The picture is 150 by 150 pixels. It shows these layers:

- A sky that follows the time of day in the selected city, with sunrise and sunset colors.
- A sun and a moon that travel an arc from sunrise to sunset. The moon shows its real phase.
- Stars at night, hidden by clouds, fog and haze.
- Clouds whose number follows the cloud cover. They darken with rain and at night.
- A rainbow opposite a low sun. It needs light rain and a sun that the clouds do not hide.
- The skyline of the selected city, with its landmarks (see Cities above). Windows and tower lights come on at night, coastal cities stand behind water, and snow stays on the roofs while it freezes.
- Rain, snow, sleet, wind streaks, fog banks, haze and lightning. Their amount follows the dials.
- A warm tint above 26 °C and a frost edge below 0 °C.
- Labels: the condition at the top left, the temperature at the top right, the city at the bottom left and the AQI at the bottom right.

A small tag under the temperature shows the state of the device: `manual`, `offline` or `loading`.

Changes ease in over about two seconds. A city change turns the weather instead of cutting to it.

Each time the condition label changes, the page sends `condition <name>` out of the `jweb` outlet, for example `condition Light Rain`. The device does not use this message yet. You can route it to start clips or change other devices.

### Conditions

The picture names the weather from the dials in this order. The first rule that matches wins.

| Condition | Rule |
| --- | --- |
| Light Snow, Snow, Heavy Snow, Blizzard | Precipitation above 0 and the temperature at or below 0 °C, or Freeze on. Snow from 2 mm, heavy snow from 5 mm, blizzard from 8 mm or from 4 mm with wind of 25 km/h or more. |
| Sleet | Precipitation above 0 and a temperature above 0 °C and at or below 2 °C. |
| Thunderstorm | Rain and a thunderstorm weather code (weather mode only). |
| Light Rain, Drizzle, Rain, Heavy Rain, Rain Storm | Rain from 2 mm, heavy rain from 6 mm, rain storm from 10 mm or from 6 mm with wind of 25 km/h or more. Drizzle needs a drizzle weather code. |
| Smog | AQI 200 or more, or PM2.5 150 or more. |
| Hazy | AQI 150 or more, or PM2.5 90 or more. |
| Fog | Weather mode: a fog weather code. Manual mode: humidity 92 % or more and wind below 8 km/h. |
| Mist | Weather mode: humidity 93 % or more and wind below 10 km/h. Manual mode: humidity 85 % or more and wind below 10 km/h. |
| Wind Storm, Windy | Wind of 28 km/h or more, or of 18 km/h or more. |
| Overcast, Cloudy, Partly Cloudy, Clear | Cloud cover of 85 %, 55 % or 20 % or more. In manual mode, humidity sets the cloud cover. |

## How the weather sets the sound

| Dial | Effect parameter |
| --- | --- |
| Air Quality | Echo feedback, Roar filter 1 resonance, shimmer damping |
| Temperature | Echo input gain (-3 to +6 dB), shimmer pitch shift (0 to 7 whole semitones), shimmer amount |
| Humidity | Shimmer mix (with Precipitation) |
| Wind | Shimmer diffusion, shimmer modulation |
| Pollution | Echo output gain (0 to +3 dB), Roar filter 1 frequency |
| Precipitation | Shimmer size, Roar mix, echo duck (on above 2 mm), shimmer mix (with Humidity) |
| Pressure | Delay feedback, shimmer decay (8 s at 980 hPa to 1 s at 1040 hPa) |
| Delay | Echo mix, delay mix, delay time, and the rate of the LFO (0.02 to 1 Hz). The LFO makes the shimmer decay breathe by up to 25 % around the Pressure value. |

The shimmer reverb has a signal inlet for its decay, its third inlet. A test in Max showed that a signal in that inlet replaces the decay attribute. In version 1, the LFO went straight into that inlet. The decay was always between 0 and 1 s, and the Pressure dial did nothing to it. Now the LFO goes through `[*~ 0.25]`, `[+~ 1.]` and `[*~]`, and Pressure sets the multiplier.

## Open and test the device

1. Put the folder `sounds_of_the_weather_turning_v2 Project` in `~/Documents/Max 9/Max for Live Devices/`. It is there already on the computer where it was made.
2. Drag `sounds_of_the_weather_turning_v2.amxd` onto an audio track in Live 12.
3. Open the Max Console. If you see a red error, stop and fix it first.
4. Select a city. Make sure that the dials move after about one second. Make sure that the text next to the City menu changes from `loading` to `fetched` and the time.
5. Select a second city. Make sure that the picture turns to the new weather and the skyline changes.
6. Set Mode to Manual. Make sure that the seven weather dials are no longer grey. Turn the Precipitation dial to 10. Make sure that the picture shows rain and that the label says Rain Storm.
7. Turn off Wi-Fi and select a city. Make sure that the tag says `offline` and that the dials keep their values. Make sure that the text next to the City menu says `no data`.
8. Turn on Wi-Fi and click Refresh. Make sure that the text next to the City menu shows the new time.

### What to listen for

- Temperature changes the echo input by at most 9 dB over its full range. A city change makes no jump in level that you notice.
- Humidity and Precipitation both change the shimmer mix.
- Pressure changes the reverb length. Low pressure gives a long tail.
- At high Delay values, the reverb tail swells and shrinks slowly.

## Freeze and publish

1. Open the device in the Max editor.
2. Click the Freeze button in the device toolbar, then save the device.
3. Move the project folder to another place, then load the frozen device in Live again.
4. Make sure that the picture still loads. If the picture is blank, the page did not go into the frozen device.

## Edit the picture

You can open `other/weather-pixel.html` in a web browser. Without Max, the page shows test controls, a city menu and eleven scenarios, for example sunset, thunderstorm, rainbow and smog. Add `?city=Panama%20City` to the address to start with a city. The sketch code is at the top of the file. The p5.js library is in the last script block.

The sketch uses p5 in instance mode. Do not change it to global mode. In global mode, p5 replaces `window.max` with its own `max()` function, and the page can no longer talk to Max.

## What changed from version 1

- The weather comes from Open-Meteo. The device needs no API token. The WAQI token field is gone, because the device hid it at load and never saved the token.
- The device has real precipitation, cloud cover, weather codes and the day phase of the city. Version 1 estimated rain from humidity and pressure, so a dry day below 1010 hPa showed rain.
- The picture is part of the device. Version 1 loaded it from an absolute path on one laptop and loaded p5 from the internet.
- One path carries the weather: fetch, dials, effects and picture. Version 1 also sent the weather to page functions that did not exist.
- A failed fetch keeps the last values. Version 1 set all dials to zero.
- The device fetches every 10 minutes and fetches once per city change, not twice.
- The echo input range is -3 to +6 dB. It was 0.5 to 20 dB.
- Each effect parameter has one dial. Version 1 had two dials each on echo feedback, shimmer damping and shimmer modulation.
- Precipitation now reaches the shimmer mix.
- The LFO runs at 0.02 to 1 Hz. It ran up to 100 Hz. It no longer replaces the shimmer decay, so the Pressure dial now sets the reverb length.
- The controls have Info View text.
- The dials have sensible start values and clear names in Live.
- Copies of the device on different tracks do not share data.
- The City menu has 29 cities in alphabetical order, each with its own skyline. Version 1 had 17 cities and no skylines.
- The patch has 115 objects. Version 1 had 144.
