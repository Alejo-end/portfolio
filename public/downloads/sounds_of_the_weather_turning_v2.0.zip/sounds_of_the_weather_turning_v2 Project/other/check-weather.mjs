// Checks code/weather.js against the live Open-Meteo service, without Max.
// Run it from a terminal:  node "other/check-weather.mjs"
// It fetches every city once and reports values outside the dial ranges,
// failed requests, and a day phase that disagrees with Open-Meteo.
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const script = fs.readFileSync(path.join(here, "..", "code", "weather.js"), "utf8");

// Stand-ins for the Max objects that weather.js uses
const dicts = new Map();
let anon = 0;
const single = (v) => Array.isArray(v) ? (v.length === 1 ? single(v[0]) : v.map(single))
    : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, single(x)])) : v;
class Dict {
    constructor(name) { this.name = name || "u" + (++anon); if (!dicts.has(this.name)) dicts.set(this.name, {}); }
    set(k, v) { dicts.get(this.name)[k] = v; }
    stringify() { return JSON.stringify(dicts.get(this.name)); }
}
const pending = [];
const raw = {};
let outs = [];
const max = {
    Dict, console, jsarguments: ["weather.js"],
    post: (s) => outs.push(["post", String(s).trim()]),
    Task: class { schedule() {} cancel() {} },
    outlet: (n, ...a) => {
        outs.push([n, ...a]);
        if (n !== 1) return;
        const r = dicts.get(a[1]);
        pending.push((async () => {
            let status = 0, body = null;
            try {
                const res = await fetch(r.url);
                status = res.status;
                body = await res.json();
            } catch (e) {
                body = { error: true, reason: String(e) };
            }
            raw[r.response_dict] = { status, body };
            dicts.set(r.response_dict, { status, body: single(body) });
            max.dictionary(r.response_dict);
        })());
    },
};
vm.createContext(max);
vm.runInContext(script, max);
const cities = vm.runInContext("CITIES", max);

const problems = [];
console.log("city             local   °C    %  km/h    hPa  mm/h code cloud phase aqi pm2.5");
for (let i = 0; i < cities.length; i++) {
    outs = [];
    max.city(i);
    while (pending.length) await pending.shift();
    const name = cities[i][0];
    const dials = outs.filter((o) => o[0] === 0).pop();
    const scene = outs.filter((o) => o[0] === 2).pop();
    const fc = Object.entries(raw).filter(([k]) => k.includes("-forecast-")).pop()[1];
    if (!dials) {
        problems.push(`${name}: no data (${fc.status} ${JSON.stringify(fc.body).slice(0, 80)})`);
        continue;
    }
    const [, aqi, h, w, t, p, pm, precip] = dials;
    const [, , , code, cloud, phase, status] = scene;
    const c = fc.body.current;
    console.log(name.padEnd(16), c.time.slice(11), String(t).padStart(5), String(h).padStart(4), String(w).padStart(5),
        String(p).padStart(7), String(precip).padStart(5), String(code).padStart(4), String(cloud).padStart(5),
        phase.toFixed(2).padStart(5), String(aqi).padStart(4), String(pm).padStart(5));
    if (status !== 1) problems.push(`${name}: status ${status}`);
    const text = outs.filter((o) => o[0] === 3).pop();
    if (!text || text[2] !== "fetched" || !/^\d\d:\d\d$/.test(text[3])) problems.push(`${name}: status text ${JSON.stringify(text)}`);
    if ((phase < 1) !== (c.is_day === 1)) problems.push(`${name}: day phase ${phase.toFixed(3)}, but is_day is ${c.is_day}`);
    const ranges = { t: [t, -20, 45], h: [h, 0, 100], w: [w, 0, 35], p: [p, 980, 1040], aqi: [aqi, 0, 300], pm25: [pm, 0, 200], precip: [precip, 0, 15] };
    for (const [k, [v, lo, hi]] of Object.entries(ranges)) {
        if (!(v >= lo && v <= hi)) problems.push(`${name}: ${k} = ${v} is outside the dial range ${lo} to ${hi}, so the dial clamps it`);
    }
}
console.log(problems.length ? "\n" + problems.join("\n") : "\nAll cities are fine.");
