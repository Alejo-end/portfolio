// Live weather for Sounds of the Weather Turning.
// Data comes from Open-Meteo (forecast and air quality). It needs no API key.
//
// in:  city <menu index>     select a city and fetch at once
//      manual <0|1>          1 = the dials are played by hand, the weather does not move them
//      refresh               fetch again now
//      resend                send the scene again (the page asks for it when it has loaded)
//      dictionary <name>     a response from maxurl
//
// out 0: aqi humidity wind temperature pressure pm25 precipitation   to the dials
// out 1: dictionary <request>                                        to maxurl
// out 2: scene manual code cloud dayphase status city                to jweb
// out 3: set <text>                                                  to the status text next to the City menu

autowatch = 1;
inlets = 1;
outlets = 4;

// Same order as the items of the City menu. The page draws a skyline for each name.
const CITIES = [
    ["Amsterdam", 52.3676, 4.9041],
    ["Barcelona", 41.3874, 2.1686],
    ["Berlin", 52.52, 13.405],
    ["Bogotá", 4.711, -74.0721],
    ["Buenos Aires", -34.6037, -58.3816],
    ["Cairo", 30.0444, 31.2357],
    ["Copenhagen", 55.6761, 12.5683],
    ["Delhi", 28.6139, 77.209],
    ["Dubai", 25.2048, 55.2708],
    ["Helsinki", 60.1699, 24.9384],
    ["Istanbul", 41.0082, 28.9784],
    ["London", 51.5072, -0.1276],
    ["Mexico City", 19.4326, -99.1332],
    ["Mumbai", 19.076, 72.8777],
    ["New York", 40.7128, -74.006],
    ["Panama City", 8.9824, -79.5199],
    ["Paris", 48.8566, 2.3522],
    ["Phoenix", 33.4484, -112.074],
    ["Reykjavík", 64.1466, -21.9426],
    ["Rio de Janeiro", -22.9068, -43.1729],
    ["Rome", 41.9028, 12.4964],
    ["San Francisco", 37.7749, -122.4194],
    ["Seoul", 37.5665, 126.978],
    ["Shanghai", 31.2304, 121.4737],
    ["Singapore", 1.2903, 103.8519],
    ["Sydney", -33.8688, 151.2093],
    ["Tokyo", 35.6762, 139.6503],
    ["Toronto", 43.6532, -79.3832],
    ["Washington", 38.9072, -77.0369],
];

// Minutes between fetches. A number after the file name in the box sets it, for example [v8 weather.js 5].
const REFRESH_MS = (Number(jsarguments[1]) > 0 ? Number(jsarguments[1]) : 10) * 60 * 1000;

const FORECAST = {
    url: "https://api.open-meteo.com/v1/forecast",
    current: "temperature_2m,relative_humidity_2m,precipitation,weather_code,cloud_cover,pressure_msl,wind_speed_10m,is_day",
    daily: "sunrise,sunset",
};
const AIR = {
    url: "https://air-quality-api.open-meteo.com/v1/air-quality",
    current: "us_aqi,pm2_5",
};

// Typical rain or snow rate in mm per hour for each WMO weather code.
// The measured amount is often 0 for light showers, so the code sets a floor.
const CODE_MM = {
    51: 0.3, 53: 0.8, 55: 1.5, 56: 0.5, 57: 1.5,
    61: 1.5, 63: 4, 65: 8, 66: 1.5, 67: 6,
    71: 1, 73: 3, 75: 6, 77: 0.5,
    80: 2, 81: 5, 82: 10, 85: 2, 86: 6,
    95: 6, 96: 8, 99: 12,
};

// Response dictionaries are named after this device and the request number,
// so two copies of the device never read each other's replies,
// and a late reply for a city that is no longer selected is ignored.
const uid = Math.floor(Math.random() * 1e9).toString(36);
const prefix = "sowt-" + uid + "-";

let cityIndex = 0;
let isManual = 0;
let seq = 0;
let haveForecast = false;

const dials = { aqi: 40, h: 60, w: 8, t: 15, p: 1013, pm25: 10, precip: 0 };
const scene = { code: -1, cloud: -1, phase: -1, status: -1 };

const timer = new Task(fetchNow);

function city(i) {
    i = Math.floor(Number(i));
    if (!(i >= 0 && i < CITIES.length)) return;
    if (i !== cityIndex) {
        haveForecast = false;
        scene.code = scene.cloud = scene.phase = -1;
        outlet(3, "set", "loading");
    }
    cityIndex = i;
    scene.status = -1;
    sendScene();
    fetchNow();
}

function manual(v) {
    isManual = v ? 1 : 0;
    if (!isManual) sendDials();
    sendScene();
}

function refresh() {
    fetchNow();
}

function resend() {
    sendScene();
}

function dictionary(name) {
    name = String(name);
    if (name.indexOf(prefix) !== 0) return;
    const parts = name.slice(prefix.length).split("-");
    if (Number(parts[1]) !== seq) return;

    const body = readBody(name);
    if (parts[0] === "forecast") onForecast(body);
    else if (parts[0] === "air") onAir(body);
}

function fetchNow() {
    seq++;
    const c = CITIES[cityIndex];
    const where = { latitude: c[1], longitude: c[2], timezone: "auto" };
    request("forecast", FORECAST.url, Object.assign({}, where, {
        current: FORECAST.current, daily: FORECAST.daily, forecast_days: 1,
    }));
    request("air", AIR.url, Object.assign({}, where, { current: AIR.current }));
    timer.cancel();
    timer.schedule(REFRESH_MS);
}
fetchNow.local = 1;

function request(kind, url, params) {
    const query = Object.keys(params)
        .map((k) => k + "=" + encodeURIComponent(String(params[k])))
        .join("&");
    const req = new Dict();
    req.set("url", url + "?" + query);
    req.set("http_method", "get");
    req.set("parse_type", "json");
    req.set("timeout", 20);
    req.set("response_dict", prefix + kind + "-" + seq);
    outlet(1, "dictionary", req.name);
}
request.local = 1;

// Returns the parsed JSON body, or null when the request failed.
function readBody(name) {
    let response;
    try {
        response = JSON.parse(new Dict(name).stringify());
    } catch (e) {
        return null;
    }
    let body = response.body;
    if (typeof body === "string") {
        try {
            body = JSON.parse(body);
        } catch (e) {
            return null;
        }
    }
    if (!body || typeof body !== "object" || body.error || !body.current) return null;
    return body;
}
readBody.local = 1;

function onForecast(body) {
    if (!body) {
        scene.status = 0;
        // With older data for this city, the text keeps the time of that data.
        if (!haveForecast) outlet(3, "set", "no data");
        post("weather: no forecast for " + CITIES[cityIndex][0] + ", keeping the last values\n");
        sendScene();
        return;
    }
    const c = body.current;
    const daily = body.daily || {};
    dials.t = num(c.temperature_2m, dials.t);
    dials.h = num(c.relative_humidity_2m, dials.h);
    dials.w = num(c.wind_speed_10m, dials.w);
    dials.p = num(c.pressure_msl, dials.p);
    dials.precip = precipRate(num(c.precipitation, 0), num(c.interval, 900), num(c.weather_code, 0));
    scene.code = num(c.weather_code, -1);
    scene.cloud = num(c.cloud_cover, -1);
    scene.phase = dayPhase(c.time, first(daily.sunrise), first(daily.sunset), c.is_day);
    scene.status = 1;
    haveForecast = true;
    sendDials();
    sendScene();
    outlet(3, "set", "fetched", clock());
}
onForecast.local = 1;

function onAir(body) {
    if (!body) return; // keep the last air values
    dials.aqi = num(body.current.us_aqi, dials.aqi);
    dials.pm25 = num(body.current.pm2_5, dials.pm25);
    sendDials();
}
onAir.local = 1;

function sendDials() {
    if (isManual || !haveForecast) return;
    outlet(0, dials.aqi, dials.h, dials.w, dials.t, dials.p, dials.pm25, dials.precip);
}
sendDials.local = 1;

function sendScene() {
    outlet(2, "scene", isManual, scene.code, scene.cloud, scene.phase, scene.status, CITIES[cityIndex][0]);
}
sendScene.local = 1;

// mm per hour from the amount of the last interval and the weather code.
function precipRate(amount, intervalSec, code) {
    const measured = amount > 0 && intervalSec > 0 ? (amount * 3600) / intervalSec : 0;
    return Math.round(Math.max(measured, CODE_MM[code] || 0) * 10) / 10;
}
precipRate.local = 1;

// 0 to 1 from sunrise to sunset, 1 to 2 through the night. All times are local to the city.
function dayPhase(now, rise, set, isDay) {
    const n = minutes(now);
    const r = minutes(rise);
    const s = minutes(set);
    if (!isFinite(n) || !isFinite(r) || !isFinite(s) || s <= r) return isDay ? 0.5 : 1.5;
    if (n >= r && n <= s) return (n - r) / (s - r);
    const night = 1440 - (s - r);
    return 1 + (n > s ? n - s : n + 1440 - s) / night;
}
dayPhase.local = 1;

// The time on this computer as HH:MM.
function clock() {
    const d = new Date();
    return ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2);
}
clock.local = 1;

function minutes(iso) {
    const m = /T(\d\d):(\d\d)/.exec(String(iso || ""));
    return m ? Number(m[1]) * 60 + Number(m[2]) : NaN;
}
minutes.local = 1;

// Max dictionaries store an array of one item as a single value.
function first(v) {
    return Array.isArray(v) ? v[0] : v;
}
first.local = 1;

function num(v, fallback) {
    const n = Number(v);
    return v === null || v === undefined || v === "" || !isFinite(n) ? fallback : n;
}
num.local = 1;
